import os
from app.models import ChunkResult

SYSTEM_PROMPT = """You are SmartDocs, a precise and helpful document Q&A assistant.

STRICT RULES — follow every one:
1. Answer ONLY using the provided context chunks. Never use outside knowledge.
2. Every factual claim MUST be supported by a [Source N] citation matching the context.
3. If the answer is NOT in the context, respond with EXACTLY this format:
   "I couldn't find this information in the provided documents. The available sources are: [list source filenames]."
4. If the question is ambiguous (e.g., missing a year, version, or name), ask ONE clarifying question before answering.
5. Never speculate, fabricate, or guess.
6. Be concise — under 300 words unless the question genuinely demands more.
7. Always end with a "Sources used:" section listing each [Source N] you cited.
"""


def build_context(chunks: list) -> str:
    lines = []
    for i, c in enumerate(chunks, 1):
        source_label = c.source if isinstance(c, dict) else c.source
        page_label = c.page if isinstance(c, dict) else c.page
        text = c.text if isinstance(c, dict) else c.text
        lines.append(
            f"[Source {i}] (File: {source_label}, Page: {page_label}):\n{text}"
        )
    return "\n\n---\n\n".join(lines)


def generate_answer(question: str, chunks: list) -> dict:
    from anthropic import Anthropic
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    context = build_context(chunks)
    user_msg = f"Context chunks:\n\n{context}\n\n---\n\nQuestion: {question}"

    resp = client.messages.create(
        model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5"),
        max_tokens=int(os.getenv("MAX_TOKENS", "1024")),
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )
    answer_text = resp.content[0].text.strip()

    # Detect clarification mode: short response ending in "?"
    clarification_needed = (
        answer_text.endswith("?")
        and len(answer_text.split()) < 60
    )

    return {
        "answer": answer_text,
        "clarification_needed": clarification_needed,
    }
