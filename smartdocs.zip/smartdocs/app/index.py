import faiss
import numpy as np
import json
import os
from pathlib import Path


def _paths():
    return (
        os.getenv("FAISS_INDEX_PATH", "data/faiss.index"),
        os.getenv("CHUNKS_PATH", "data/chunks.json"),
    )


def build_and_save(chunks: list, embeddings: np.ndarray):
    """Build FAISS IndexFlatIP (cosine after L2-norm), save to disk."""
    index_path, chunks_path = _paths()
    dim = embeddings.shape[1]
    faiss.normalize_L2(embeddings)
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    Path(index_path).parent.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, index_path)
    with open(chunks_path, "w", encoding="utf-8") as f:
        json.dump(chunks, f, indent=2, ensure_ascii=False)
    print(f"[index] Saved {index.ntotal} vectors → {index_path}")


def load_index():
    index_path, chunks_path = _paths()
    if not os.path.exists(index_path):
        raise FileNotFoundError(f"FAISS index not found at {index_path}. Run /ingest first.")
    index = faiss.read_index(index_path)
    with open(chunks_path, encoding="utf-8") as f:
        chunks = json.load(f)
    return index, chunks


def index_exists() -> bool:
    index_path, _ = _paths()
    return os.path.exists(index_path)
