import os
import numpy as np

EMBED_MODEL = "text-embedding-3-small"
BATCH_SIZE  = 100


def get_client():
    from openai import OpenAI
    return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def embed_texts(texts: list) -> np.ndarray:
    """Return (N, 1536) float32 numpy array."""
    client = get_client()
    all_embs = []
    for i in range(0, len(texts), BATCH_SIZE):
        batch = texts[i: i + BATCH_SIZE]
        resp = client.embeddings.create(model=EMBED_MODEL, input=batch)
        all_embs.extend([e.embedding for e in resp.data])
    return np.array(all_embs, dtype=np.float32)


def embed_query(query: str) -> np.ndarray:
    return embed_texts([query])[0]
