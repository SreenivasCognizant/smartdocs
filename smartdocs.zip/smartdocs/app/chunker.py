import tiktoken

CHUNK_SIZE = 512   # tokens
OVERLAP    = 64    # tokens

enc = tiktoken.get_encoding("cl100k_base")


def chunk_text(text: str, source: str, page) -> list:
    """Split text into overlapping token-bounded chunks."""
    tokens = enc.encode(text)
    chunks = []
    i = 0
    chunk_idx = 0
    # Sanitise source for chunk_id
    safe_src = source.replace("\\", "/").replace(" ", "_")
    while i < len(tokens):
        window = tokens[i: i + CHUNK_SIZE]
        chunk_str = enc.decode(window)
        chunk_str = chunk_str.strip()
        if chunk_str:
            chunks.append({
                "chunk_id": f"{safe_src}::p{page}::c{chunk_idx}",
                "text": chunk_str,
                "source": source,
                "page": page,
            })
        i += CHUNK_SIZE - OVERLAP
        chunk_idx += 1
    return chunks
