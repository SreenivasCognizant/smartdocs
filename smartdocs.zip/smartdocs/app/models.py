from pydantic import BaseModel
from typing import Optional, List


class IngestRequest(BaseModel):
    doc_path: str = "data/docs"


class QueryRequest(BaseModel):
    question: str
    top_k: Optional[int] = 5
    session_id: Optional[str] = None


class ChunkResult(BaseModel):
    chunk_id: str
    text: str
    source: str
    page: Optional[int] = None
    score: float


class QueryResponse(BaseModel):
    answer: str
    sources: List[ChunkResult]
    guardrail_triggered: bool
    clarification_needed: bool


class HealthResponse(BaseModel):
    status: str
    index_size: int
    model: str


class IngestResponse(BaseModel):
    status: str
    documents_loaded: int
    chunks_created: int
    index_size: int
    sources: List[str]
