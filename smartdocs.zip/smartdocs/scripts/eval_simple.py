"""
SmartDocs Simple Evaluation Script
===================================
Runs goldens against the live API and computes:
  - Faithfulness proxy (keyword overlap between answer and context)
  - Context recall proxy (ground truth coverage by retrieved chunks)
  - Answer relevancy (simple heuristic)

Does NOT require ragas or deepeval — works out of the box.
Run: python scripts/eval_simple.py
"""
import json
import re
import sys
import os
import time
import requests
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

API_BASE = os.getenv("API_BASE", "http://localhost:8000")
GOLDENS_PATH = "eval/goldens/goldens.json"
REPORT_DIR   = Path("eval/report")
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def load_goldens():
    with open(GOLDENS_PATH) as f:
        return json.load(f)


def query_api(question: str, top_k: int = 5) -> dict:
    r = requests.post(
        f"{API_BASE}/query",
        json={"question": question, "top_k": top_k},
        timeout=60,
    )
    r.raise_for_status()
    return r.json()


def tokenize(text: str) -> set:
    text = text.lower()
    text = re.sub(r"[^\w\s]", " ", text)
    tokens = set(text.split())
    stopwords = {"the","a","an","is","are","was","were","be","been","being",
                 "have","has","had","do","does","did","will","would","could",
                 "should","may","might","shall","can","of","to","in","for",
                 "on","with","at","by","from","up","about","into","through",
                 "during","before","after","this","that","these","those","it",
                 "its","i","you","he","she","we","they","what","which","who"}
    return tokens - stopwords


def faithfulness_score(answer: str, contexts: list) -> float:
    """How much of the answer is supported by retrieved chunks."""
    if not answer or not contexts:
        return 0.0
    ans_tokens = tokenize(answer)
    ctx_text = " ".join(c.get("text", "") for c in contexts)
    ctx_tokens = tokenize(ctx_text)
    if not ans_tokens:
        return 0.0
    overlap = ans_tokens & ctx_tokens
    return round(len(overlap) / len(ans_tokens), 3)


def context_recall_score(ground_truth: str, contexts: list) -> float:
    """How much of the ground truth is covered by retrieved chunks."""
    if not ground_truth or not contexts:
        return 0.0 if ground_truth else 1.0
    gt_tokens = tokenize(ground_truth)
    ctx_text = " ".join(c.get("text", "") for c in contexts)
    ctx_tokens = tokenize(ctx_text)
    if not gt_tokens:
        return 1.0
    overlap = gt_tokens & ctx_tokens
    return round(len(overlap) / len(gt_tokens), 3)


def relevancy_score(question: str, answer: str) -> float:
    """Simple keyword overlap between question and answer."""
    if not question or not answer:
        return 0.0
    q_tokens = tokenize(question)
    a_tokens = tokenize(answer)
    if not q_tokens:
        return 0.0
    overlap = q_tokens & a_tokens
    # Penalise "I couldn't find" answers (lower relevancy)
    if "couldn't find" in answer.lower() or "not found" in answer.lower():
        return max(0.0, round(len(overlap) / len(q_tokens), 3) - 0.2)
    return round(len(overlap) / len(q_tokens), 3)


def run_evaluation():
    print("SmartDocs Evaluation")
    print("=" * 50)

    # Check API
    try:
        r = requests.get(f"{API_BASE}/health", timeout=10)
        h = r.json()
        print(f"API status : {h.get('status')}")
        print(f"Index size : {h.get('index_size', 0)} chunks")
        print(f"Model      : {h.get('model')}")
        if h.get('index_size', 0) == 0:
            print("\n⚠  Index is empty. Run /ingest or upload documents first.")
            sys.exit(1)
    except Exception as e:
        print(f"\n✕ Cannot connect to API at {API_BASE}: {e}")
        print("  Start the server: uvicorn app.main:app --reload")
        sys.exit(1)

    goldens = load_goldens()
    print(f"\nRunning {len(goldens)} goldens...\n")

    results = []
    for g in goldens:
        print(f"  [{g['id']}] {g['question'][:60]}...")
        try:
            resp = query_api(g["question"])
            answer  = resp.get("answer", "")
            sources = resp.get("sources", [])
            guardrail = resp.get("guardrail_triggered", False)

            f_score = faithfulness_score(answer, sources)
            r_score = context_recall_score(g["ground_truth"], sources)
            rel_score = relevancy_score(g["question"], answer)

            results.append({
                "id":            g["id"],
                "question":      g["question"],
                "ground_truth":  g["ground_truth"],
                "answer":        answer[:200],
                "guardrail":     guardrail,
                "faithfulness":  f_score,
                "context_recall":r_score,
                "relevancy":     rel_score,
                "num_sources":   len(sources),
            })
            status = "✓" if f_score >= 0.6 else "~"
            print(f"    {status} F={f_score:.2f} | CR={r_score:.2f} | Rel={rel_score:.2f} | srcs={len(sources)}")
            time.sleep(0.5)  # Rate limiting
        except Exception as e:
            print(f"    ✗ ERROR: {e}")
            results.append({
                "id": g["id"], "question": g["question"],
                "ground_truth": g["ground_truth"], "answer": f"ERROR: {e}",
                "guardrail": False, "faithfulness": 0.0,
                "context_recall": 0.0, "relevancy": 0.0, "num_sources": 0,
            })

    # Summary
    df = pd.DataFrame(results)
    avg_f   = df["faithfulness"].mean()
    avg_cr  = df["context_recall"].mean()
    avg_rel = df["relevancy"].mean()

    targets = {"faithfulness": 0.8, "context_recall": 0.75, "relevancy": 0.8}

    print("\n" + "=" * 50)
    print("EVALUATION RESULTS")
    print("=" * 50)
    print(f"{'Metric':<22} {'Score':>8}  {'Target':>8}  {'Pass?':>6}")
    print("-" * 50)

    all_pass = True
    for metric, target in targets.items():
        val = df[metric].mean()
        passed = val >= target
        if not passed:
            all_pass = False
        status = "✅" if passed else "❌"
        print(f"{metric:<22} {val:>8.3f}  {target:>8.2f}  {status:>6}")

    print("-" * 50)
    print(f"\nOverall: {'✅ ALL TARGETS MET' if all_pass else '❌ SOME TARGETS MISSED'}")

    # Save CSV
    csv_path = REPORT_DIR / "eval_results.csv"
    df.to_csv(csv_path, index=False)
    print(f"\nSaved → {csv_path}")

    # Plot
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    fig.patch.set_facecolor('#0c0e14')

    # Bar chart: metrics vs targets
    metrics_labels = ["Faithfulness", "Context Recall", "Answer Relevancy"]
    achieved = [avg_f, avg_cr, avg_rel]
    target_vals = [0.80, 0.75, 0.80]
    x = range(len(metrics_labels))
    bars = ax1.bar([i - 0.2 for i in x], achieved, 0.35,
                   label="Achieved", color="#4f8ef7", zorder=3)
    ax1.bar([i + 0.2 for i in x], target_vals, 0.35,
            label="Target", color="#2dd4bf", alpha=0.7, zorder=3)
    ax1.set_xticks(list(x))
    ax1.set_xticklabels(metrics_labels, color="#e2e5f0", fontsize=10)
    ax1.set_ylim(0, 1.1)
    ax1.set_ylabel("Score", color="#8892b0")
    ax1.set_title("Metric Scores vs Targets", color="#e2e5f0", fontweight="bold")
    ax1.set_facecolor('#13151f')
    ax1.tick_params(colors="#8892b0")
    ax1.legend(facecolor="#1a1d2b", labelcolor="#e2e5f0")
    ax1.grid(axis='y', color='#2a2e42', alpha=0.5, zorder=0)
    for bar, val in zip(bars, achieved):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f"{val:.2f}", ha='center', va='bottom', color="#e2e5f0", fontsize=9)

    # Per-golden scatter
    ids = df["id"].tolist()
    ax2.plot(ids, df["faithfulness"], 'o-', color="#4f8ef7", label="Faithfulness", linewidth=1.5, markersize=5)
    ax2.plot(ids, df["context_recall"], 's-', color="#2dd4bf", label="Context Recall", linewidth=1.5, markersize=5)
    ax2.plot(ids, df["relevancy"], '^-', color="#7c5cfc", label="Relevancy", linewidth=1.5, markersize=5)
    ax2.axhline(0.8, color="#f59e0b", linestyle="--", linewidth=0.8, alpha=0.7, label="Target")
    ax2.set_ylim(0, 1.1)
    ax2.set_xlabel("Golden ID", color="#8892b0")
    ax2.set_ylabel("Score", color="#8892b0")
    ax2.set_title("Per-Golden Scores", color="#e2e5f0", fontweight="bold")
    ax2.set_facecolor('#13151f')
    ax2.tick_params(colors="#8892b0", labelsize=7)
    ax2.legend(facecolor="#1a1d2b", labelcolor="#e2e5f0", fontsize=8)
    ax2.grid(color='#2a2e42', alpha=0.5)
    plt.xticks(rotation=45)

    plt.tight_layout()
    plot_path = REPORT_DIR / "metrics_chart.png"
    plt.savefig(plot_path, dpi=150, bbox_inches='tight', facecolor=fig.get_facecolor())
    print(f"Saved → {plot_path}")
    plt.close()

    # Markdown report
    report_md = f"""# SmartDocs Evaluation Report

## System Info
- Model: `{h.get('model', 'unknown')}`
- Index size: {h.get('index_size', 0)} chunks
- Goldens run: {len(goldens)}

## Results Summary

| Metric | Target | Achieved | Pass? |
|---|---|---|---|
| Faithfulness | ≥ 0.80 | {avg_f:.3f} | {"✅" if avg_f >= 0.80 else "❌"} |
| Context Recall | ≥ 0.75 | {avg_cr:.3f} | {"✅" if avg_cr >= 0.75 else "❌"} |
| Answer Relevancy | ≥ 0.80 | {avg_rel:.3f} | {"✅" if avg_rel >= 0.80 else "❌"} |

![Metrics Chart](metrics_chart.png)

## Per-Golden Breakdown

{df[["id","question","faithfulness","context_recall","relevancy","guardrail"]].to_markdown(index=False)}

## Notes
- Faithfulness: token overlap between answer and retrieved chunks  
- Context Recall: token overlap between ground truth and retrieved chunks  
- Relevancy: keyword match between question and answer  
"""
    md_path = REPORT_DIR / "eval_report.md"
    md_path.write_text(report_md)
    print(f"Saved → {md_path}")

    return all_pass


if __name__ == "__main__":
    success = run_evaluation()
    sys.exit(0 if success else 1)
