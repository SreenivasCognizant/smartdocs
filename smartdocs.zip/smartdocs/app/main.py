import os
import random
import shutil
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from dotenv import load_dotenv

load_dotenv()

from app.models import (
    IngestRequest, QueryRequest, QueryResponse,
    HealthResponse, IngestResponse, ChunkResult
)
from app.loader import load_documents
from app.chunker import chunk_text
from app.embedder import embed_texts
from app.index import build_and_save, load_index, index_exists
from app.retriever import retrieve, reset_cache
from app.guardrails import check_query
from app.generator import generate_answer

app = FastAPI(
    title="SmartDocs Q&A API",
    description="Intelligent document assistant powered by Claude + FAISS RAG",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Serve static files (the UI)
static_dir = Path(__file__).parent.parent / "static"
static_dir.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# ─── UI ────────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def serve_ui():
    ui_path = static_dir / "index.html"
    if ui_path.exists():
        return HTMLResponse(content=ui_path.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>SmartDocs</h1><p>UI not found. Check static/index.html</p>")


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["System"])
def health():
    try:
        index, chunks = load_index()
        return HealthResponse(
            status="ok",
            index_size=index.ntotal,
            model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5"),
        )
    except FileNotFoundError:
        return HealthResponse(
            status="index_not_built",
            index_size=0,
            model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5"),
        )


# ─── Ingest via path ───────────────────────────────────────────────────────────

@app.post("/ingest", response_model=IngestResponse, tags=["Ingestion"])
def ingest(req: IngestRequest):
    """Load documents from a local path, chunk, embed, and build FAISS index."""
    docs = load_documents(req.doc_path)
    if not docs:
        raise HTTPException(
            status_code=400,
            detail=f"No supported documents found at '{req.doc_path}'. "
                   "Supported: PDF, DOCX, HTML, TXT"
        )
    all_chunks = []
    for doc in docs:
        all_chunks.extend(chunk_text(doc["text"], doc["source"], doc.get("page")))

    if not all_chunks:
        raise HTTPException(status_code=400, detail="Documents were empty after chunking.")

    texts = [c["text"] for c in all_chunks]
    embeddings = embed_texts(texts)
    build_and_save(all_chunks, embeddings)
    reset_cache()

    sources = list({c["source"] for c in all_chunks})
    return IngestResponse(
        status="ok",
        documents_loaded=len(docs),
        chunks_created=len(all_chunks),
        index_size=len(all_chunks),
        sources=sources,
    )


# ─── Upload & Ingest ───────────────────────────────────────────────────────────

@app.post("/upload", tags=["Ingestion"])
async def upload_and_ingest(files: list[UploadFile] = File(...)):
    """Upload one or more documents and ingest them immediately."""
    upload_dir = Path("data/docs")
    upload_dir.mkdir(parents=True, exist_ok=True)

    saved_paths = []
    for f in files:
        dest = upload_dir / f.filename
        with open(dest, "wb") as out:
            shutil.copyfileobj(f.file, out)
        saved_paths.append(str(dest))

    docs = []
    all_chunks = []
    for path in saved_paths:
        loaded = load_documents(path)
        docs.extend(loaded)
        for doc in loaded:
            all_chunks.extend(chunk_text(doc["text"], doc["source"], doc.get("page")))

    if not all_chunks:
        raise HTTPException(status_code=400, detail="Uploaded files contained no extractable text.")

    # If existing index, merge chunks
    existing_chunks = []
    try:
        _, existing_chunks = load_index()
    except FileNotFoundError:
        pass

    merged = existing_chunks + all_chunks
    texts = [c["text"] for c in merged]
    embeddings = embed_texts(texts)
    build_and_save(merged, embeddings)
    reset_cache()

    return {
        "status": "ok",
        "files_uploaded": [f.filename for f in files],
        "new_chunks": len(all_chunks),
        "total_chunks": len(merged),
    }


# ─── Query ─────────────────────────────────────────────────────────────────────

@app.post("/query", response_model=QueryResponse, tags=["Query"])
def query(req: QueryRequest):
    """Answer a natural language question grounded in ingested documents."""
    if not index_exists():
        raise HTTPException(
            status_code=503,
            detail="No documents indexed yet. Upload documents first via /upload or /ingest."
        )

    # 1. Guardrail check
    safety = check_query(req.question)
    if not safety.get("safe", True):
        return QueryResponse(
            answer=(
                f"⚠️ I'm unable to process this request. "
                f"Reason: {safety.get('reason', 'policy_violation')}. "
                "Please ask a question related to the indexed documents."
            ),
            sources=[],
            guardrail_triggered=True,
            clarification_needed=False,
        )

    # 2. Retrieve top-k chunks
    chunks = retrieve(req.question, top_k=req.top_k or 5)
    if not chunks:
        return QueryResponse(
            answer="No relevant content was found in the indexed documents for your question.",
            sources=[],
            guardrail_triggered=False,
            clarification_needed=False,
        )

    # 3. Generate grounded answer
    result = generate_answer(req.question, chunks)

    return QueryResponse(
        answer=result["answer"],
        sources=chunks,
        guardrail_triggered=False,
        clarification_needed=result["clarification_needed"],
    )


# ─── Documents ─────────────────────────────────────────────────────────────────

@app.get("/documents", tags=["Documents"])
def list_documents():
    """List all ingested document sources."""
    try:
        index, chunks = load_index()
        sources = list({c["source"] for c in chunks})
        return {
            "sources": sources,
            "total_chunks": len(chunks),
            "index_size": index.ntotal,
        }
    except FileNotFoundError:
        raise HTTPException(status_code=503, detail="Index not built yet.")


@app.delete("/documents", tags=["Documents"])
def clear_index():
    """Delete the FAISS index and chunk store."""
    index_path = os.getenv("FAISS_INDEX_PATH", "data/faiss.index")
    chunks_path = os.getenv("CHUNKS_PATH", "data/chunks.json")
    for path in [index_path, chunks_path]:
        if path and os.path.exists(path):
            os.remove(path)
    reset_cache()
    return {"status": "cleared", "message": "Index and chunk store deleted."}


# ─── Eval helper ───────────────────────────────────────────────────────────────

@app.get("/eval/sample", tags=["Evaluation"])
def get_eval_sample(n: int = 5):
    """Return n random chunks — useful for writing golden Q&A pairs."""
    try:
        _, chunks = load_index()
        sample = random.sample(chunks, min(n, len(chunks)))
        return {"count": len(sample), "samples": sample}
    except FileNotFoundError:
        raise HTTPException(status_code=503, detail="Index not built yet.")
