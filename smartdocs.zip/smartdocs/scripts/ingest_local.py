"""
Standalone ingest script — runs without the FastAPI server.
Usage: python scripts/ingest_local.py --path data/docs
"""
import sys
import os
import argparse

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from app.loader import load_documents
from app.chunker import chunk_text
from app.embedder import embed_texts
from app.index import build_and_save


def main():
    parser = argparse.ArgumentParser(description="Ingest documents into FAISS")
    parser.add_argument("--path", default="data/docs", help="Path to documents directory or file")
    args = parser.parse_args()

    print(f"Loading documents from: {args.path}")
    docs = load_documents(args.path)
    if not docs:
        print("No documents found. Supported: .pdf .docx .html .htm .txt")
        sys.exit(1)
    print(f"Loaded {len(docs)} document pages/sections")

    all_chunks = []
    for doc in docs:
        chunks = chunk_text(doc["text"], doc["source"], doc.get("page"))
        all_chunks.extend(chunks)
    print(f"Created {len(all_chunks)} chunks")

    print("Embedding chunks (this may take a minute)...")
    texts = [c["text"] for c in all_chunks]
    embeddings = embed_texts(texts)
    print(f"Embedded {len(embeddings)} chunks (dim={embeddings.shape[1]})")

    build_and_save(all_chunks, embeddings)
    print("Done! FAISS index ready.")


if __name__ == "__main__":
    main()
