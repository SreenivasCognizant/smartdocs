import faiss
import numpy as np
from app.embedder import embed_query
from app.index import load_index
from app.models import ChunkResult

_index = None
_chunks = None


def reset_cache():
    global _index, _chunks
    _index = None
    _chunks = None


def get_index():
    global _index, _chunks
    if _index is None:
        _index, _chunks = load_index()
    return _index, _chunks


def retrieve(question: str, top_k: int = 5) -> list:
    index, chunks = get_index()
    q_emb = embed_query(question).reshape(1, -1).astype(np.float32)
    faiss.normalize_L2(q_emb)
    scores, indices = index.search(q_emb, top_k)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1 or idx >= len(chunks):
            continue
        c = chunks[idx]
        results.append(ChunkResult(
            chunk_id=c["chunk_id"],
            text=c["text"],
            source=c["source"],
            page=c.get("page"),
            score=float(score),
        ))
    return results
