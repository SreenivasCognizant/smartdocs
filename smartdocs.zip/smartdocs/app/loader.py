import os
from pathlib import Path


def load_documents(path: str) -> list:
    """Load PDF, DOCX, or HTML from file or directory.
    Returns list of {text, source, page} dicts."""
    p = Path(path)
    if not p.exists():
        return []
    files = list(p.rglob("*")) if p.is_dir() else [p]
    docs = []
    for f in files:
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        try:
            if ext == ".pdf":
                docs.extend(_load_pdf(f))
            elif ext == ".docx":
                docs.extend(_load_docx(f))
            elif ext in (".html", ".htm"):
                docs.extend(_load_html(f))
            elif ext == ".txt":
                docs.extend(_load_txt(f))
        except Exception as e:
            print(f"[loader] Warning: could not load {f}: {e}")
    return docs


def _load_pdf(path: Path) -> list:
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    results = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        text = text.strip()
        if text:
            results.append({"text": text, "source": str(path), "page": i + 1})
    return results


def _load_docx(path: Path) -> list:
    from docx import Document
    doc = Document(str(path))
    text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    if text.strip():
        return [{"text": text, "source": str(path), "page": None}]
    return []


def _load_html(path: Path) -> list:
    from bs4 import BeautifulSoup
    try:
        soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
    except Exception:
        soup = BeautifulSoup(path.read_bytes(), "html.parser")
    text = soup.get_text(separator="\n", strip=True)
    if text.strip():
        return [{"text": text, "source": str(path), "page": None}]
    return []


def _load_txt(path: Path) -> list:
    try:
        text = path.read_text(encoding="utf-8").strip()
    except Exception:
        text = path.read_bytes().decode("latin-1").strip()
    if text:
        return [{"text": text, "source": str(path), "page": None}]
    return []
